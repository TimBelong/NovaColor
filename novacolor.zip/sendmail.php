<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';

$mail = new PHPMailer(true);
$mail->CharSet = 'UTF-8';
$mail->setLanguage('en', 'PHPMailer/language');
$mail->IsHTML(true);

//От кого письмо
$mail->setFrom('tpe3egol@gmail.com', 'Valya');
//Кому отправлять
$mail->addAddress('mrbelongtim@gmail.com');
//Тема Письма
$mail->Subject = 'Новое сообщение от NovaColor';

//Тело Пиьсьма
$body = '<h1>Данные на обработку!</h1>';

if (trim(!empty($_POST['name']))) {
    $body .= '<p><strong>Имя: </strong> ' . $_POST['name'] . '</p>';
}
if (trim(!empty($_POST['email']))) {
    $body .= '<p><strong>E-mail: </strong> ' . $_POST['email'] . '</p>';
}
if (trim(!empty($_POST['phone']))) {
    $body .= '<p><strong>Имя: </strong> ' . $_POST['phone'] . '</p>';
}
if (trim(!empty($_POST['message']))) {
    $body .= '<p><strong>Имя: </strong> ' . $_POST['message'] . '</p>';
}

$mail->Body = $body;

if ($mail->send()) {
    $message = 'Chyba při odesílání formuláře';
} else {
    $message = 'Vaše kontaktní údaje byly odeslány';
}

$response = ['message' => $message];

header('Content-type: application/json');
echo json_encode($response);
?>